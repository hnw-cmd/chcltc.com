const fs = require('node:fs/promises');
const path = require('node:path');
const ExcelJS = require('exceljs');
const iconv = require('iconv-lite');
const layout = require('./yamato_layout.json');

const KEYS = ['senderName','senderPhone','senderZip','senderAddress','senderApartment','billingCode','fareCode','nameRules','defaultName','saveDir','subscriptionReview','defaultMode','fallbackName'];
const settingsFile = directory => path.join(directory(), 'yamato_settings.json');
const rulesFile = directory => path.join(directory(), 'yamato_product_rules.csv');
function cellText(cell) {
  const v=cell.value;
  if (v == null) return '';
  if (v instanceof Date) return [v.getFullYear(),String(v.getMonth()+1).padStart(2,'0'),String(v.getDate()).padStart(2,'0')].join('-');
  if (typeof v === 'object') return String(v.result ?? v.text ?? (v.richText ? v.richText.map(x=>x.text).join('') : '') ?? '');
  return String(v);
}
module.exports = (ipcMain, app, dialog, directory) => {
  ipcMain.handle('load-yamato-settings', async () => {
    try {
      const saved=JSON.parse(await fs.readFile(settingsFile(directory),'utf8'));
      return {settings:Object.fromEntries(KEYS.filter(k=>typeof saved?.[k]==='string').map(k=>[k,saved[k]]))};
    } catch(e) {return e.code==='ENOENT'?{settings:null}:{error:`ヤマト設定を読めませんでした: ${e.message}`}}
  });
  ipcMain.handle('save-yamato-settings', async (_event, values) => {
    if(!values || KEYS.some(k=>typeof values[k]!=='string'||values[k].length>10000))return {error:'設定内容を確認してください'};
    try {await fs.writeFile(settingsFile(directory),JSON.stringify(Object.fromEntries(KEYS.map(k=>[k,values[k]])),null,2));return {saved:true}}
    catch(e){return {error:`設定を保存できませんでした: ${e.message}`}}
  });
  ipcMain.handle('load-yamato-rules', async () => {
    try {
      const bytes=await fs.readFile(rulesFile(directory));
      if(bytes.length>2_000_000)return {error:'商品ルールが大きすぎます'};
      try{return {csv:new TextDecoder('utf-8',{fatal:true}).decode(bytes)}}
      catch{return {csv:iconv.decode(bytes,'cp932')}}
    } catch(e){
      if(e.code==='ENOENT'){const csv=await fs.readFile(path.join(__dirname,'yamato_product_rules.csv'),'utf8');await fs.writeFile(rulesFile(directory),csv,'utf8');return {csv};}
      return {error:`商品ルールを読めませんでした: ${e.message}`};
    }
  });
  ipcMain.handle('save-yamato-rules', async (_event,csv) => {
    if(typeof csv!=='string'||csv.length>2_000_000||!csv.replace(/^\uFEFF/,'').startsWith('配送サイズ,商品ID,商品名'))return {error:'商品ルールCSVの形式を確認してください'};
    try{await fs.writeFile(rulesFile(directory),csv,'utf8');return {saved:true}}
    catch(e){return {error:`商品ルールを保存できませんでした: ${e.message}`}}
  });
  ipcMain.handle('read-yamato-source-xlsx', async (_event, bytes) => {
    if(!bytes || bytes.byteLength>20_000_000)return {error:'Excelファイルが大きすぎます'};
    try {
      const book=new ExcelJS.Workbook();await book.xlsx.load(Buffer.from(bytes));
      const sheet=book.worksheets[0];if(!sheet)return {error:'シートがありません'};
      if(sheet.rowCount>10001||sheet.columnCount>150)return {error:'行数または列数が多すぎます'};
      const rows=[];sheet.eachRow((row)=>{const vals=[];for(let c=1;c<=sheet.columnCount;c++)vals.push(cellText(row.getCell(c)));if(vals.some(x=>x.trim()))rows.push(vals)});
      return {rows};
    } catch(e){return {error:`Excelを読めませんでした: ${e.message}`}}
  });
  ipcMain.handle('save-yamato-xlsx', async (_event,payload) => {
    const rows=payload?.rows;
    if(!Array.isArray(rows)||!rows.length||rows.length>10000||rows.some(r=>!Array.isArray(r)||r.length!==95||r.some(v=>typeof v!=='string'&&typeof v!=='number')))
      return {error:'ヤマトExcelのデータ形式を確認してください'};
    try {
      const book=new ExcelJS.Workbook();book.creator='リピスト送り状変換';
      const sheet=book.addWorksheet('外部データ取り込み基本レイアウト');
      sheet.addRow(layout);
      sheet.getRow(1).font={bold:true};sheet.getRow(1).alignment={wrapText:true,vertical:'top'};sheet.getRow(1).height=55;
      sheet.columns.forEach((column,i)=>{column.width=[12,15,19,22,28,33].includes(i+1)?30:19});
      for(const row of rows){const values=row.map((v,i)=>(i===33||i===34)&&/^\d+$/.test(String(v))?Number(v):v);sheet.addRow(values)}
      sheet.views=[{state:'frozen',ySplit:1}];
      const bytes=Buffer.from(await book.xlsx.writeBuffer());
      let target;
      const settings=JSON.parse(await fs.readFile(settingsFile(directory),'utf8').catch(()=>'{ }'));
      const folder=settings.saveDir;
      const name=`yamato_${new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Tokyo'})}.xlsx`;
      if(folder){
        if(!path.isAbsolute(folder)||!(await fs.stat(folder).catch(()=>null))?.isDirectory())return {error:'設定したExcel保存先が見つかりません'};
        for(let n=1;n<=1000;n++){
          target=path.join(folder,`yamato_${new Date().toLocaleDateString('sv-SE',{timeZone:'Asia/Tokyo'})}${n>1?'_'+n:''}.xlsx`);
          let handle;
          try{handle=await fs.open(target,'wx')}catch(e){if(e.code==='EEXIST')continue;throw e}
          try{await handle.writeFile(bytes)}finally{await handle.close()}return {saved:true,filePath:target};
        }
        return {error:'同名のExcelファイルが多すぎます'};
      }
      const result=await dialog.showSaveDialog({defaultPath:path.join(directory(),name),filters:[{name:'Excelファイル',extensions:['xlsx']}]});
      if(result.canceled||!result.filePath)return {canceled:true};
      target=result.filePath;await fs.writeFile(target,bytes);return {saved:true,filePath:target};
    }catch(e){return {error:`ヤマトExcelを保存できませんでした: ${e.message}`}}
  });
};
