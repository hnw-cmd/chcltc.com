const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('node:path');
const fs = require('node:fs/promises');
const iconv = require('iconv-lite');
require('./preferences_main')(ipcMain, portableDirectory);
require('./watchlist_main')(ipcMain, portableDirectory);
require('./yamato_main')(ipcMain, app, dialog, portableDirectory);

const SETTINGS_KEYS = ['senderName', 'senderPhone', 'senderZip', 'senderAddress1', 'senderAddress2', 'codPayment', 'subscriptionAutoReview', 'itemNameRules', 'defaultItemName', 'fallbackItemName', 'packetSaveDir', 'takuhaiSaveDir'];
const LEGACY_SETTINGS_KEYS = ['perfumeKeywords', 'foodKeywords'];
const readableSettings = saved => Object.fromEntries([...SETTINGS_KEYS, ...LEGACY_SETTINGS_KEYS].filter(k => typeof saved[k] === 'string').map(k => [k, saved[k]]));
function portableDirectory() {
  return process.env.PORTABLE_EXECUTABLE_DIR || (app.isPackaged ? path.dirname(app.getPath('exe')) : __dirname);
}
function settingsPath() {
  return path.join(portableDirectory(), 'settings.json');
}

ipcMain.handle('load-product-rules', async () => {
  try {
    const bytes = await fs.readFile(path.join(portableDirectory(), 'product_rules.csv'));
    if (bytes.length > 2_000_000) return { error: '商品ルールCSVが大きすぎます' };
    let csv;
    try { csv = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch { csv = iconv.decode(bytes, 'cp932'); }
    return { csv };
  } catch (error) {
    if (error.code === 'ENOENT') {const csv=await fs.readFile(path.join(__dirname,'product_rules.csv'),'utf8');await fs.writeFile(path.join(portableDirectory(),'product_rules.csv'),csv,'utf8');return {csv};}
    return { error: `商品ルールCSVを読み込めませんでした: ${error.message}` };
  }
});

ipcMain.handle('save-product-rules', async (_event, csv) => {
  if (typeof csv !== 'string' || csv.length > 2_000_000 || !csv.startsWith('発送方法,商品ID,商品名'))
    return { error: '商品ルールCSVの形式を確認してください' };
  try {
    await fs.writeFile(path.join(portableDirectory(), 'product_rules.csv'), csv, 'utf8');
    return { saved: true };
  } catch (error) { return { error: `商品ルールを保存できませんでした: ${error.message}` }; }
});

ipcMain.handle('load-settings', async () => {
  try {
    const saved = JSON.parse(await fs.readFile(settingsPath(), 'utf8'));
    if (!saved || typeof saved !== 'object' || Array.isArray(saved)) throw Error('設定ファイルの形式が正しくありません');
    return { settings: readableSettings(saved) };
  } catch (error) {
    if (error.code === 'ENOENT') {
      // 1.3.0で保存済みの設定は、初回のみ読み込み、次の保存時に持ち運び用フォルダーへ移します。
      try {
        const oldFile = path.join(app.getPath('appData'), 'Ripost-Sagawa-CSV-Converter', 'settings.json');
        const old = JSON.parse(await fs.readFile(oldFile, 'utf8'));
        if (!old || typeof old !== 'object' || Array.isArray(old)) throw Error('以前の設定ファイルの形式が正しくありません');
        return { settings: readableSettings(old) };
      } catch (oldError) {
        if (oldError.code === 'ENOENT') return { settings: null };
        return { error: `以前の設定を読み込めませんでした: ${oldError.message}` };
      }
    }
    return { error: `設定を読み込めませんでした: ${error.message}` };
  }
});

ipcMain.handle('save-settings', async (_event, values) => {
  if (!values || typeof values !== 'object' || Array.isArray(values) ||
      SETTINGS_KEYS.some(k => typeof values[k] !== 'string' || values[k].length > (k === 'itemNameRules' ? 20000 : 2000))) {
    return { error: '設定の形式を確認してください' };
  }
  try {
    const file = settingsPath();
    await fs.mkdir(path.dirname(file), { recursive: true });
    await fs.writeFile(file, JSON.stringify(Object.fromEntries(SETTINGS_KEYS.map(k => [k, values[k]])), null, 2), 'utf8');
    return { saved: true };
  } catch (error) { return { error: `設定を保存できませんでした: ${error.message}` }; }
});

ipcMain.handle('select-save-directory', async () => {
  const result = await dialog.showOpenDialog({properties:['openDirectory','createDirectory'],defaultPath:portableDirectory()});
  return result.canceled || !result.filePaths?.[0] ? {canceled:true} : {directory:result.filePaths[0]};
});

function createWindow() {
  const win = new BrowserWindow({
    width: 1300,
    height: 850,
    minWidth: 760,
    minHeight: 600,
    autoHideMenuBar: true,
    title: 'リピスト → 佐川・ヤマト 送り状変換',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(() => ({action: 'deny'}));
  win.webContents.on('will-navigate', event => event.preventDefault());
}

ipcMain.handle('save-shipping-csv', async (_event, payload) => {
  if (!payload || !['packet', 'takuhai', 'report'].includes(payload.kind) ||
      typeof payload.csv !== 'string' || payload.csv.length > 30_000_000 ||
      typeof payload.filename !== 'string' || !/^sagawa_(yupacket|takuhai|review)_[\d-]+\.csv$/.test(payload.filename)) {
    return { error: '保存するCSVの形式を確認してください' };
  }
  try {
    const bytes = payload.kind === 'packet'
      ? iconv.encode(payload.csv, 'cp932')
      : Buffer.from('\uFEFF' + payload.csv, 'utf8');
    if (payload.kind === 'packet' && iconv.decode(bytes, 'cp932') !== payload.csv)
      return { error: 'ゆうパケット便用CSVにShift_JISで表せない文字があります。絵文字や特殊文字を確認してください。' };
    let directory = '';
    if (payload.kind !== 'report') {
      try {
        const saved=JSON.parse(await fs.readFile(settingsPath(),'utf8'));
        directory=saved?.[payload.kind === 'packet' ? 'packetSaveDir' : 'takuhaiSaveDir'] || '';
      } catch (e) { if(e.code !== 'ENOENT') return {error:`保存先の設定を読めませんでした: ${e.message}`}; }
    }
    if(directory){
      const location=await fs.stat(directory).catch(()=>null);
      if(!path.isAbsolute(directory) || !location?.isDirectory())return {error:'設定した保存先が見つかりません。設定の「CSV保存先」から選び直してください。'};
      const parsed=path.parse(payload.filename);
      for(let n=0;n<1000;n++){
        const target=path.join(directory,`${parsed.name}${n ? '_'+(n+1) : ''}${parsed.ext}`);
        let handle;
        try{handle=await fs.open(target,'wx')}
        catch(e){if(e.code==='EEXIST')continue;throw e}
        try{await handle.writeFile(bytes)}catch(e){await handle.close();await fs.unlink(target).catch(()=>{});throw e}
        await handle.close();return {saved:true,filePath:target};
      }
      return {error:'同名のCSVが多すぎるため保存できませんでした。'};
    }
    const result = await dialog.showSaveDialog({ defaultPath: path.join(portableDirectory(), payload.filename),
      filters: [{name:'CSVファイル',extensions:['csv']}] });
    if (result.canceled || !result.filePath) return { canceled: true };
    await fs.writeFile(result.filePath, bytes);
    return { saved: true,filePath:result.filePath };
  } catch (error) { return { error: error.message }; }
});

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
