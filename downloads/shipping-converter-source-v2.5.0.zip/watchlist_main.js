const fs=require('node:fs/promises'),path=require('node:path');
module.exports=(ipcMain,directory)=>{
 const file=()=>path.join(directory(),'customer_watchlist.json');
 const valid=rows=>Array.isArray(rows)&&rows.length<=50000&&rows.every(r=>r&&['id','name','address','phone','note'].every(k=>typeof r[k]==='string'&&r[k].length<=3000));
 ipcMain.handle('load-watchlist',async()=>{try{const rows=JSON.parse(await fs.readFile(file(),'utf8'));if(!valid(rows))throw Error('データ形式が不正です');return {rows}}catch(e){if(e.code==='ENOENT'){try{const rows=JSON.parse(await fs.readFile(path.join(__dirname,'customer_watchlist.json'),'utf8'));await fs.writeFile(file(),JSON.stringify(rows,null,2),'utf8');return {rows}}catch(f){return {error:'注意リストを読み込めません: '+f.message}}}return {error:'注意リストを読み込めません: '+e.message}}});
 ipcMain.handle('save-watchlist',async(_e,rows)=>{if(!valid(rows))return {error:'注意リストの内容を確認してください'};try{await fs.writeFile(file()+'.tmp',JSON.stringify(rows,null,2),'utf8');await fs.rename(file()+'.tmp',file());return {saved:true}}catch(e){return {error:'保存できません: '+e.message}}});
};
