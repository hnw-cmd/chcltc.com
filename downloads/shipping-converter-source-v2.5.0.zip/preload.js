const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('desktopApp', {
  loadUiPreferences: () => ipcRenderer.invoke('load-ui-preferences'),
  saveUiPreferences: settings => ipcRenderer.invoke('save-ui-preferences', settings),
  loadWatchlist: () => ipcRenderer.invoke('load-watchlist'),
  saveWatchlist: rows => ipcRenderer.invoke('save-watchlist', rows),
  saveCsv: payload => ipcRenderer.invoke('save-shipping-csv', payload),
  loadSettings: () => ipcRenderer.invoke('load-settings'),
  saveSettings: values => ipcRenderer.invoke('save-settings', values),
  loadProductRules: () => ipcRenderer.invoke('load-product-rules'),
  saveProductRules: csv => ipcRenderer.invoke('save-product-rules', csv),
  selectSaveFolder: () => ipcRenderer.invoke('select-save-directory'),
  loadYamatoSettings: () => ipcRenderer.invoke('load-yamato-settings'),
  saveYamatoSettings: values => ipcRenderer.invoke('save-yamato-settings', values),
  loadYamatoRules: () => ipcRenderer.invoke('load-yamato-rules'),
  saveYamatoRules: csv => ipcRenderer.invoke('save-yamato-rules', csv),
  readYamatoSourceXlsx: bytes => ipcRenderer.invoke('read-yamato-source-xlsx', bytes),
  saveYamatoXlsx: payload => ipcRenderer.invoke('save-yamato-xlsx', payload)
});
