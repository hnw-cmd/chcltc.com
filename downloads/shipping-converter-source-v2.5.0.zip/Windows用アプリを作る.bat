@echo off
chcp 65001 >nul
cd /d "%~dp0"
where npm >nul 2>nul
if errorlevel 1 (
  echo Node.js が見つかりません。README.txt の手順1をご覧ください。
  pause
  exit /b 1
)
echo 必要な部品をインストールしています。初回は数分かかる場合があります。
call npm install
if errorlevel 1 (
  echo インストールに失敗しました。ネット接続を確認してください。
  pause
  exit /b 1
)
echo Windows 用のアプリを作成しています。
call npm run build:windows
if errorlevel 1 (
  echo アプリ作成に失敗しました。表示されたエラーを確認してください。
  pause
  exit /b 1
)
copy /Y "%~dp0product_rules.csv" "%~dp0dist\product_rules.csv" >nul
copy /Y "%~dp0yamato_product_rules.csv" "%~dp0dist\yamato_product_rules.csv" >nul
copy /Y "%~dp0customer_watchlist.json" "%~dp0dist\customer_watchlist.json" >nul
echo.
echo 完了しました。dist フォルダー内の exe と両方の商品ルールCSVを一緒にご利用ください。
pause
